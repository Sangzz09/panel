#pragma once
#include <cmath>

struct Vector2 {
    float x, y;
};

struct Vector3 {
    float x, y, z;

    Vector3 operator-(const Vector3& other) const {
        return { x - other.x, y - other.y, z - other.z };
    }

    Vector3 operator+(const Vector3& other) const {
        return { x + other.x, y + other.y, z + other.z };
    }

    Vector3 operator/(float factor) const {
        return { x / factor, y / factor, z / factor };
    }

    float Length() const {
        return std::sqrt(x * x + y * y + z * z);
    }
};

struct Matrix4x4 {
    float m[4][4];
};

inline const float PI = 3.14159265359f;

inline Vector3 CalcAngle(const Vector3& src, const Vector3& dst) {
    Vector3 delta = dst - src;
    float hyp = std::sqrt(delta.x * delta.x + delta.z * delta.z);
    Vector3 angle;
    angle.x = std::atan2(-delta.y, hyp) * 180.0f / PI; // Pitch (around X axis)
    angle.y = std::atan2(delta.x, delta.z) * 180.0f / PI; // Yaw (around Y axis)
    angle.z = 0.0f;
    return angle;
}

inline Vector3 ClampAngle(Vector3 angle) {
    while (angle.y > 180.0f) angle.y -= 360.0f;
    while (angle.y < -180.0f) angle.y += 360.0f;
    if (angle.x > 89.0f) angle.x = 89.0f;
    if (angle.x < -89.0f) angle.x = -89.0f;
    angle.z = 0.0f;
    return angle;
}

inline Vector2 WorldToScreen(const Vector3& world, const Matrix4x4& viewProj, int screenWidth, int screenHeight) {
    float x = world.x * viewProj.m[0][0] + world.y * viewProj.m[0][1] + world.z * viewProj.m[0][2] + viewProj.m[0][3];
    float y = world.x * viewProj.m[1][0] + world.y * viewProj.m[1][1] + world.z * viewProj.m[1][2] + viewProj.m[1][3];
    // float z = world.x * viewProj.m[2][0] + world.y * viewProj.m[2][1] + world.z * viewProj.m[2][2] + viewProj.m[2][3];
    float wVal = world.x * viewProj.m[3][0] + world.y * viewProj.m[3][1] + world.z * viewProj.m[3][2] + viewProj.m[3][3];

    if (wVal < 0.01f) return { -1, -1 };

    float invW = 1.0f / wVal;
    float sx = (x * invW + 1.0f) * 0.5f * (float)screenWidth;
    float sy = (1.0f - (y * invW)) * 0.5f * (float)screenHeight;

    return { sx, sy };
}
