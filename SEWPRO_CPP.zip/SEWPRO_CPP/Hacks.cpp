// Temporary replacement to allow tool to run
#include "Hacks.h"
#include "Memory.h"
#include "Offsets.h"
#include "Math.h"
#include "Config.h"

int GetTeam(uint32_t playerPtr) {
    auto avMgr = Memory::Read<uint32_t>(playerPtr + Offsets::AvatarManager);
    if (!avMgr) return -1;
    auto av = Memory::Read<uint32_t>(avMgr + Offsets::Avatar);
    if (!av) return -1;
    auto avData = Memory::Read<uint32_t>(av + Offsets::Avatar_Data);
    if (!avData) return -1;
    return Memory::Read<bool>(avData + Offsets::Avatar_Data_IsTeam) ? 1 : 0;
}

Vector3 GetBonePos(uint32_t playerPtr, Offsets::Bones boneType) {
    auto shadow = Memory::Read<uint32_t>(playerPtr + Offsets::Player_ShadowBase);
    if (!shadow) return {0,0,0};
    return Memory::Read<Vector3>(shadow + boneType);
}

void Hacks::AimbotLoop() {
    while (true) {
        Sleep(5);
        if (!Config::aimbot_enabled || !Memory::libil2cpp || !Memory::dynamicInitBase) continue;

        uint32_t initBasePtr = Memory::Read<uint32_t>(Memory::libil2cpp + Memory::dynamicInitBase);
        if (!initBasePtr) continue;
        uint32_t staticClass = Memory::Read<uint32_t>(initBasePtr + Offsets::StaticClass);
        if (!staticClass) continue;
        uint32_t currentMatch = Memory::Read<uint32_t>(staticClass + Offsets::CurrentMatch);
        if (!currentMatch) continue;

        uint32_t localPlayer = Memory::Read<uint32_t>(currentMatch + Offsets::LocalPlayer);
        if (!localPlayer) continue;

        Vector3 localPos = Memory::Read<Vector3>(localPlayer + Offsets::XPose);
        int localTeam = GetTeam(localPlayer);

        uint32_t dict = Memory::Read<uint32_t>(currentMatch + Offsets::DictionaryEntities);
        if (!dict) continue;
        uint32_t entityArray = Memory::Read<uint32_t>(dict + 0x10);
        if (!entityArray) continue;

        for (int i = 0; i < 64; i++) {
            // For 32-bit Lists/Arrays, elements usually start at 0x10 (header is 0x10) and take 4 bytes each.
            uint32_t ent = Memory::Read<uint32_t>(entityArray + 0x10 + (i * 4));
            if (!ent || ent == localPlayer) continue;
            if (Memory::Read<bool>(ent + Offsets::Player_IsDead)) continue;
            if (GetTeam(ent) == localTeam) continue;

            Vector3 bonePos = GetBonePos(ent, Offsets::Bones::Head);
            if (bonePos.x == 0 && bonePos.y == 0 && bonePos.z == 0) continue;

            Vector3 aimAngle = CalcAngle(localPos, bonePos);
            Vector3 curAngle = Memory::Read<Vector3>(localPlayer + Offsets::AimRotation);

            Vector3 delta = ClampAngle(aimAngle - curAngle);
            Vector3 newAngle = ClampAngle(curAngle + (delta / Config::aim_smooth));

            Memory::Write(localPlayer + Offsets::AimRotation, newAngle);
            break; // Aims at first valid target
        }
    }
}

void Hacks::MemoryHackLoop() {
    while (true) {
        Sleep(100);
        if (!Memory::libil2cpp || !Memory::dynamicInitBase) continue;

        uint32_t initBasePtr = Memory::Read<uint32_t>(Memory::libil2cpp + Memory::dynamicInitBase);
        if (!initBasePtr) continue;
        uint32_t staticClass = Memory::Read<uint32_t>(initBasePtr + Offsets::StaticClass);
        if (!staticClass) continue;
        uint32_t currentMatch = Memory::Read<uint32_t>(staticClass + Offsets::CurrentMatch);
        if (!currentMatch) continue;
        
        uint32_t lp = Memory::Read<uint32_t>(currentMatch + Offsets::LocalPlayer);
        
        if (lp) {
            // Speedhack
            float speed = Config::hack_speed ? 5.0f : 1.0f;
            Memory::Write<float>(lp + Offsets::RunSpeedUpScale, speed);

            // No Reload
            uint8_t state = Config::hack_no_reload ? 1 : 0;
            Memory::Write<uint8_t>(lp + Offsets::NoReload, state);

            // God Mode (Spoof isDead state)
            if (Config::hack_god_mode) {
                Memory::Write<bool>(lp + Offsets::Player_IsDead, false);
            }

            // No Recoil
            uint32_t weapon = Memory::Read<uint32_t>(lp + Offsets::Weapon);
            if (weapon) {
                uint32_t weaponData = Memory::Read<uint32_t>(weapon + Offsets::WeaponData);
                if (weaponData) {
                    float recoil = Config::hack_no_recoil ? 0.0f : 1.0f;
                    Memory::Write<float>(weaponData + Offsets::WeaponRecoil, recoil);
                }
            }
        }
    }
}



