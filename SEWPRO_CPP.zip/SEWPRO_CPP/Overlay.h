#pragma once
#include <windows.h>
#include <d3d11.h>
#include "imgui.h"
#include "imgui_impl_win32.h"
#include "imgui_impl_dx11.h"

namespace Overlay {
    extern HWND overlayWnd;
    extern HWND gameWnd;
    
    bool Initialize();
    void Cleanup();
    void RenderLoop();
    void SetupImGuiStyle();
}
