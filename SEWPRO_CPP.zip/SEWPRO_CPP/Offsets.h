#pragma once
#include <cstdint>

namespace Offsets {
    constexpr uint32_t Il2Cpp = 0;
    constexpr uint32_t UnityCpp = 0;
    constexpr uint32_t InitBase = 0xA986E9C;
    constexpr uint32_t StaticClass = 0x5C;

    // ==========================================================
    // Match Related
    // ==========================================================
    constexpr uint32_t CurrentMatch = 0x50;
    constexpr uint32_t MatchStatus = 0x8C;
    constexpr uint32_t LocalPlayer = 0x94;
    constexpr uint32_t DictionaryEntities = 0x68;

    // ==========================================================
    // Player
    // ==========================================================
    constexpr uint32_t Player_IsDead = 0x50;
    constexpr uint32_t Player_Name = 0x2DC;
    constexpr uint32_t Player_Data = 0x48;
    constexpr uint32_t Player_ShadowBase = 0x18B8;
    constexpr uint32_t XPose = 0x78;
    constexpr uint32_t AvatarManager = 0x4C0;
    constexpr uint32_t Avatar = 0xA8;
    constexpr uint32_t Avatar_IsVisible = 0x95;
    constexpr uint32_t Avatar_Data = 0x14;
    constexpr uint32_t Avatar_Data_IsTeam = 0x59;
    constexpr uint32_t PlayerID = 0x268;
    constexpr uint32_t BaseProfileInfo = 0x18CC;
    constexpr uint32_t IsClientBot = 0x2E4;

    // ==========================================================
    // Camera
    // ==========================================================
    constexpr uint32_t FollowCamera = 0x450;
    constexpr uint32_t Camera = 0x18;
    constexpr uint32_t MainCameraTransform = 0x24C;
    constexpr uint32_t AimRotation = 0x400;
    constexpr uint32_t FollowCamera_m_RightOffset = 0x60;
    constexpr uint32_t FollowCamera_m_UpOffset = 0x64;
    constexpr uint32_t FollowCamera_m_VisionSpeed = 0x48;

    // ==========================================================
    // Observer
    // ==========================================================
    constexpr uint32_t CurrentObserver = 0xB4;
    constexpr uint32_t ObserverPlayer = 0x28;

    // ==========================================================
    // Weapon
    // ==========================================================
    constexpr uint32_t Weapon = 0x3F4;
    constexpr uint32_t WeaponData = 0x58;
    constexpr uint32_t WeaponRecoil = 0xC;
    constexpr uint32_t UnkPlayerWeaponInfoClass = 0x4A8;
    constexpr uint32_t IsCombineWeapon = 0xD8;
    constexpr uint32_t WeaponOnHand = 0x54;
    constexpr uint32_t CombineWeaponOnHand = 0x58;
    constexpr uint32_t WeaponInfo = 0x64;
    constexpr uint32_t WeaponID = 0x14;

    // ==========================================================
    // Silent Aim / Aimbot
    // ==========================================================
    constexpr uint32_t LastAimingInfoFromWeapon = 0x978;
    constexpr uint32_t isFiring = 0x540;
    constexpr uint32_t StartPosition = 0x38;
    constexpr uint32_t RayDir = 0x2C;
    constexpr uint32_t LockedAimingCollider = 0x54;
    constexpr uint32_t Collider = 0x4A4;

    // ==========================================================
    // Player Attributes
    // ==========================================================
    constexpr uint32_t PlayerAttributes = 0x4BC;
    constexpr uint32_t NoReload = 0x99;
    constexpr uint32_t RunSpeedUpScale = 0x1D8;

    // ==========================================================
    // Misc
    // ==========================================================
    constexpr uint32_t GameTimer = 0x10;
    constexpr uint32_t FixedDeltaTime = 0x24;
    constexpr uint32_t ViewMatrix = 0xE8;

    // ==========================================================
    // Latest Bones
    // ==========================================================
    enum Bones : uint32_t {
        Head = 0x458,
        Spine = 0x460, 
        Hip = 0x45C,
        RightShoulder = 0x490,
        LeftShoulder = 0x48C,  
        LeftHand = 0x484,
        LeftWrist = 0x454,  
        LeftCalf = 0x474,
        RightFoot = 0x478, 
        Root = 0x46C,
        LeftFoot = 0x47C,
        RightWrist = 0x480, 
        RightCalf = 0x470, 
        RightElbow = 0x49C, 
        LeftElbow = 0x4A0,
        RightWristJoint = 0x494,
        LeftWristJoint = 0x498,
        BoneCollider = 0x4A4
    };
}
