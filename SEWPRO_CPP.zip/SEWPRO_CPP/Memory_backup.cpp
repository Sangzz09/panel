#include "Memory.h"
#include <algorithm>

namespace Memory {
    HANDLE hProcess = NULL;
    uintptr_t libil2cpp = 0;
    uintptr_t emulatorBase = 0;

    bool AttachProcess(const wchar_t* processName) {
        PROCESSENTRY32W pe;
        HANDLE hSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
        if (hSnap == INVALID_HANDLE_VALUE) return false;
        
        pe.dwSize = sizeof(PROCESSENTRY32W);
        if (Process32FirstW(hSnap, &pe)) {
            do {
                if (_wcsicmp(pe.szExeFile, processName) == 0) {
                    hProcess = OpenProcess(PROCESS_ALL_ACCESS, FALSE, pe.th32ProcessID);
                    break;
                }
            } while (Process32NextW(hSnap, &pe));
        }
        CloseHandle(hSnap);
        return hProcess != NULL;
    }

    bool ReadRaw(uintptr_t address, void* buffer, size_t size) {
        if (!hProcess) return false;
        SIZE_T bytesRead;
        return ReadProcessMemory(hProcess, (LPCVOID)address, buffer, size, &bytesRead) && bytesRead == size;
    }

    bool WriteRaw(uintptr_t address, const void* buffer, size_t size) {
        if (!hProcess) return false;
        SIZE_T bytesWritten;
        return WriteProcessMemory(hProcess, (LPVOID)address, buffer, size, &bytesWritten) && bytesWritten == size;
    }

    uintptr_t FindLibraryBase() {
        if (!hProcess) return 0;
        MEMORY_BASIC_INFORMATION mbi;
        uintptr_t addr = 0x0;
        
        while (VirtualQueryEx(hProcess, (LPCVOID)addr, &mbi, sizeof(mbi))) {
            if (mbi.State == MEM_COMMIT && (mbi.Protect & (PAGE_READWRITE | PAGE_READONLY | PAGE_EXECUTE_READWRITE | PAGE_EXECUTE_READ | PAGE_EXECUTE_WRITECOPY))) {
                if (mbi.RegionSize > 0 && mbi.RegionSize <= 0x10000000) { 
                    std::vector<byte> buffer(mbi.RegionSize);
                    SIZE_T bytesRead;
                    if (ReadProcessMemory(hProcess, (LPCVOID)mbi.BaseAddress, buffer.data(), (size_t)mbi.RegionSize, &bytesRead) && bytesRead > 0) {
                        const byte pattern[] = { 0x7F, 0x45, 0x4C, 0x46, 0x01, 0x01, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
                        const byte pattern64[] = { 0x7F, 0x45, 0x4C, 0x46, 0x02, 0x01, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };

                        for (size_t i = 0; i < bytesRead - sizeof(pattern); i += 0x1000) { // Usually aligned to 0x1000
                            if (memcmp(&buffer[i], pattern, sizeof(pattern)) == 0 || 
                                memcmp(&buffer[i], pattern64, sizeof(pattern64)) == 0) {
                                
                                uintptr_t elfBase = (uintptr_t)mbi.BaseAddress + i;
                                
                                // Search for "il2cpp_init" to confirm it is libil2cpp.so
                                const char* sig = "il2cpp_init";
                                return elfBase; } }
                    }
                }
            }
            addr = (uintptr_t)mbi.BaseAddress + mbi.RegionSize;
            if (addr == 0 || addr > 0x7FFFFFFFFFFF) break;
        }
        return 0;
    }
}












