#pragma once
#include "Offsets.h"
#include "Memory.h"
#include "Config.h"
#include "Math.h"
#include <thread>

namespace Hacks {
    void AimbotLoop();
    void MemoryHackLoop();
}
