#pragma once
#include <windows.h>
#include <tlhelp32.h>
#include <cstdint>
#include <vector>
#include <string>

namespace Memory {
    extern HANDLE hProcess;
    extern uintptr_t libil2cpp;
    extern uintptr_t vmBase;
    extern uint32_t dynamicInitBase;

    bool AttachProcess(const wchar_t* processName);
    uintptr_t FindLibraryBase();
    uint32_t ScanForInitBase();
    
    bool ReadRaw(uintptr_t address, void* buffer, size_t size);
    bool WriteRaw(uintptr_t address, const void* buffer, size_t size);

    template<typename T>
    inline T Read(uintptr_t address) {
        T val = T();
        if (address < 0x100000) return val;
        
        // Translate 32-bit guest address to 64-bit host address
        if (address < 0x100000000ULL && vmBase != 0) {
            address = address + (vmBase & 0xFFFFFFFF00000000ULL);
        }
        
        ReadRaw(address, &val, sizeof(T));
        return val;
    }

    template<typename T>
    inline bool Write(uintptr_t address, const T& val) {
        if (address < 0x100000) return false;
        
        // Translate 32-bit guest address to 64-bit host address
        if (address < 0x100000000ULL && vmBase != 0) {
            address = address + (vmBase & 0xFFFFFFFF00000000ULL);
        }
        
        return WriteRaw(address, &val, sizeof(T));
    }
}
