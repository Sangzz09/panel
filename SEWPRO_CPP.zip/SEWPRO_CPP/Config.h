#pragma once

namespace Config {
    // Aimbot settings
    inline bool aimbot_enabled = false;
    inline float aim_smooth = 5.0f;
    inline int bone_target = 0; // Assuming 0 is head or some default

    // ESP settings
    inline bool esp_enabled = false;
    inline float esp_max_distance = 1000.0f;
    inline bool esp_draw_box = true;
    inline bool esp_draw_line = true;

    // Hacks
    inline bool hack_speed = false;
    inline bool hack_no_reload = false;
    inline bool hack_god_mode = false;
    inline bool hack_no_recoil = false;

    // Internal State
    inline bool showMenu = true;
    inline bool gameAttached = false;
    inline bool il2cppFound = false;
    inline char connectionStatus[256] = "Waiting for Emulator...";
}
