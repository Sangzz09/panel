#include "Memory.h"

namespace Memory {
    HANDLE hProcess = NULL;
    uintptr_t libil2cpp = 0;
    uintptr_t vmBase = 0;
    uint32_t dynamicInitBase = 0;

    bool AttachProcess(const wchar_t* processName) {
        PROCESSENTRY32W pe;
        HANDLE hSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
        if (hSnap == INVALID_HANDLE_VALUE) return false;
        
        pe.dwSize = sizeof(PROCESSENTRY32W);
        if (Process32FirstW(hSnap, &pe)) {
            do {
                if (_wcsicmp(pe.szExeFile, processName) == 0) {
                    hProcess = OpenProcess(PROCESS_ALL_ACCESS, FALSE, pe.th32ProcessID);
                    break;
                }
            } while (Process32NextW(hSnap, &pe));
        }
        CloseHandle(hSnap);
        return hProcess != NULL;
    }

    bool ReadRaw(uintptr_t address, void* buffer, size_t size) {
        if (!hProcess) return false;
        SIZE_T bytesRead;
        return ReadProcessMemory(hProcess, (LPCVOID)address, buffer, size, &bytesRead) && bytesRead == size;
    }

    bool WriteRaw(uintptr_t address, const void* buffer, size_t size) {
        if (!hProcess) return false;
        SIZE_T bytesWritten;
        return WriteProcessMemory(hProcess, (LPVOID)address, buffer, size, &bytesWritten) && bytesWritten == size;
    }

    uint32_t ScanForInitBase() {
        if (!libil2cpp) return 0;
        
        // Scan from 80MB to 250MB offset
        uint32_t startOffset = 0x5000000;
        uint32_t endOffset = 0xFA00000;
        uint32_t size = endOffset - startOffset;
        
        std::vector<byte> buffer(size);
        SIZE_T bytesRead;
        if (!ReadProcessMemory(hProcess, (LPCVOID)(libil2cpp + startOffset), buffer.data(), size, &bytesRead)) {
            return 0;
        }
        
        for (uint32_t i = 0; i < bytesRead - 4; i += 4) {
            uint32_t val = *(uint32_t*)&buffer[i];
            if (val > 0x10000000 && val < 0xF0000000) {
                uint32_t staticClass = Memory::Read<uint32_t>(val + 0x5C); // Offsets::StaticClass
                if (staticClass > 0x10000000 && staticClass < 0xF0000000) {
                    uint32_t currentMatch = Memory::Read<uint32_t>(staticClass + 0x50); // Offsets::CurrentMatch
                    if (currentMatch > 0x10000000 && currentMatch < 0xF0000000) {
                        uint32_t localPlayer = Memory::Read<uint32_t>(currentMatch + 0x94); // Offsets::LocalPlayer
                        if (localPlayer > 0x10000000 && localPlayer < 0xF0000000) {
                            uint32_t avMgr = Memory::Read<uint32_t>(localPlayer + 0x4C0); // Offsets::AvatarManager
                            if (avMgr > 0x10000000 && avMgr < 0xF0000000) {
                                return startOffset + i;
                            }
                        }
                    }
                }
            }
        }
        return 0;
    }

    uintptr_t FindLibraryBase() {
        if (!hProcess) return 0;
        MEMORY_BASIC_INFORMATION mbi;
        uintptr_t addr = 0x0;
        
        const char* target = "il2cpp_init";
        size_t targetLen = strlen(target);

        while (VirtualQueryEx(hProcess, (LPCVOID)addr, &mbi, sizeof(mbi))) {
            if (mbi.State == MEM_COMMIT && (mbi.Protect & (PAGE_READWRITE | PAGE_READONLY | PAGE_EXECUTE_READWRITE | PAGE_EXECUTE_READ | PAGE_EXECUTE_WRITECOPY))) {
                if (mbi.RegionSize > 0 && mbi.RegionSize <= 0x80000000ULL) { 
                    size_t chunkSize = 1024 * 1024 * 10; // 10 MB chunks
                    std::vector<byte> buffer(chunkSize);
                    
                    for (uintptr_t offset = 0; offset < mbi.RegionSize; offset += chunkSize - 0x1000) {
                        size_t readSize = (mbi.RegionSize - offset) > chunkSize ? chunkSize : (mbi.RegionSize - offset);
                        SIZE_T bytesRead;
                        if (ReadProcessMemory(hProcess, (LPCVOID)((uintptr_t)mbi.BaseAddress + offset), buffer.data(), readSize, &bytesRead) && bytesRead > 0) {
                            for (size_t i = 0; i < bytesRead - targetLen; i++) {
                                if (memcmp(&buffer[i], target, targetLen) == 0 && buffer[i + targetLen] == '\0') {
                                    // Found "il2cpp_init\0", scan backwards for ELF header
                                    uintptr_t foundAddr = (uintptr_t)mbi.BaseAddress + offset + i;
                                    uintptr_t searchStart = foundAddr & ~0xFFFULL;
                                    
                                    for (uintptr_t elfSearch = searchStart; elfSearch > searchStart - 0x10000000; elfSearch -= 0x1000) {
                                        byte elfBuf[4];
                                        if (ReadRaw(elfSearch, elfBuf, 4)) {
                                            if (elfBuf[0] == 0x7F && elfBuf[1] == 'E' && elfBuf[2] == 'L' && elfBuf[3] == 'F') {
                                                extern uintptr_t vmBase;
                                                vmBase = (uintptr_t)mbi.AllocationBase;
                                                return elfSearch;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            addr = (uintptr_t)mbi.BaseAddress + mbi.RegionSize;
            if (addr == 0 || addr > 0x7FFFFFFFFFFF) break;
        }
        return 0;
    }
}














