#include "Overlay.h"
#include "Math.h"
#include "Memory.h"
#include "Offsets.h"
#include "Config.h"
#include <dwmapi.h>

#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "dxgi.lib")

namespace Overlay {
    HWND overlayWnd = NULL;
    HWND gameWnd = NULL;
    
    ID3D11Device* g_pd3dDevice = nullptr;
    ID3D11DeviceContext* g_pd3dDeviceContext = nullptr;
    IDXGISwapChain* g_pSwapChain = nullptr;
    ID3D11RenderTargetView* g_mainRenderTargetView = nullptr;

    void CreateRenderTarget() { ID3D11Texture2D* pBackBuffer;
        g_pSwapChain->GetBuffer(0, IID_PPV_ARGS(&pBackBuffer));
        g_pd3dDevice->CreateRenderTargetView(pBackBuffer, nullptr, &g_mainRenderTargetView);
        pBackBuffer->Release();
    }

    void CleanupRenderTarget() {
        if (g_mainRenderTargetView) { g_mainRenderTargetView->Release(); g_mainRenderTargetView = nullptr; }
    }

    bool CreateDeviceD3D(HWND hWnd) { DXGI_SWAP_CHAIN_DESC sd;
        ZeroMemory(&sd, sizeof(sd));
        sd.BufferCount = 2;
        sd.BufferDesc.Width = 0;
        sd.BufferDesc.Height = 0;
        sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
        sd.BufferDesc.RefreshRate.Numerator = 60;
        sd.BufferDesc.RefreshRate.Denominator = 1;
        sd.Flags = DXGI_SWAP_CHAIN_FLAG_ALLOW_MODE_SWITCH;
        sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
        sd.OutputWindow = hWnd;
        sd.SampleDesc.Count = 1;
        sd.SampleDesc.Quality = 0;
        sd.Windowed = TRUE;
        sd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;

        UINT createDeviceFlags = 0;
        D3D_FEATURE_LEVEL featureLevel;
        const D3D_FEATURE_LEVEL featureLevelArray[2] = { D3D_FEATURE_LEVEL_11_0, D3D_FEATURE_LEVEL_10_0, };
        if (D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, createDeviceFlags, featureLevelArray, 2, D3D11_SDK_VERSION, &sd, &g_pSwapChain, &g_pd3dDevice, &featureLevel, &g_pd3dDeviceContext) != S_OK)
            return false;

        CreateRenderTarget(); return true;
    }

    void CleanupDeviceD3D() {
        CleanupRenderTarget();
        if (g_pSwapChain) { g_pSwapChain->Release(); g_pSwapChain = nullptr; }
        if (g_pd3dDeviceContext) { g_pd3dDeviceContext->Release(); g_pd3dDeviceContext = nullptr; }
        if (g_pd3dDevice) { g_pd3dDevice->Release(); g_pd3dDevice = nullptr; }
    }
} // end namespace for extern

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

namespace Overlay {
    LRESULT WINAPI WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam) {
        if (ImGui_ImplWin32_WndProcHandler(hWnd, msg, wParam, lParam))
            return true;

        switch (msg) {
        case WM_SIZE:
            if (g_pd3dDevice != nullptr && wParam != SIZE_MINIMIZED) {
                CleanupRenderTarget();
                g_pSwapChain->ResizeBuffers(0, (UINT)LOWORD(lParam), (UINT)HIWORD(lParam), DXGI_FORMAT_UNKNOWN, 0);
                CreateRenderTarget(); }
            return 0;
        case WM_SYSCOMMAND:
            if ((wParam & 0xfff0) == SC_KEYMENU) return 0;
            break;
        case WM_DESTROY:
            PostQuitMessage(0);
            return 0;
        }
        return DefWindowProc(hWnd, msg, wParam, lParam);
    }

    void SetupImGuiStyle() {
        ImGui::StyleColorsDark();
        ImGuiStyle& style = ImGui::GetStyle();
        style.WindowRounding = 5.0f;
        style.Colors[ImGuiCol_WindowBg] = ImVec4(0.06f, 0.06f, 0.06f, 0.94f);
        style.Colors[ImGuiCol_TitleBg] = ImVec4(0.16f, 0.29f, 0.48f, 1.00f);
        style.Colors[ImGuiCol_TitleBgActive] = ImVec4(0.16f, 0.29f, 0.48f, 1.00f);
        style.Colors[ImGuiCol_Button] = ImVec4(0.20f, 0.25f, 0.29f, 1.00f);
        style.Colors[ImGuiCol_ButtonHovered] = ImVec4(0.28f, 0.56f, 1.00f, 1.00f);
        style.Colors[ImGuiCol_ButtonActive] = ImVec4(0.06f, 0.53f, 0.98f, 1.00f);
        style.Colors[ImGuiCol_CheckMark] = ImVec4(0.28f, 0.56f, 1.00f, 1.00f);
    }

    bool Initialize() { WNDCLASSEXW wc = { sizeof(wc), CS_CLASSDC, WndProc, 0L, 0L, GetModuleHandle(nullptr), nullptr, nullptr, nullptr, nullptr, L"SEWPRO_Overlay", nullptr };
        RegisterClassExW(&wc); DWORD exStyle = WS_EX_TOPMOST | WS_EX_LAYERED | WS_EX_TOOLWINDOW;
        overlayWnd = CreateWindowExW(exStyle, wc.lpszClassName, L"SEWPRO", WS_POPUP, 100, 100, 800, 600, nullptr, nullptr, wc.hInstance, nullptr);

        if (!CreateDeviceD3D(overlayWnd)) {
            CleanupDeviceD3D();
            UnregisterClassW(wc.lpszClassName, wc.hInstance);
            return false;
        }

        SetLayeredWindowAttributes(overlayWnd, 0, 255, LWA_ALPHA);
        MARGINS margins = { -1, -1, -1, -1 };
        DwmExtendFrameIntoClientArea(overlayWnd, &margins);

        if (!Config::showMenu) {
            SetWindowLong(overlayWnd, GWL_EXSTYLE, exStyle | WS_EX_TRANSPARENT);
        }

        ShowWindow(overlayWnd, SW_SHOW);
        UpdateWindow(overlayWnd);

        IMGUI_CHECKVERSION();
        ImGui::CreateContext();
        ImGuiIO& io = ImGui::GetIO(); (void)io;
        io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;

        SetupImGuiStyle();

        ImGui_ImplWin32_Init(overlayWnd);
        ImGui_ImplDX11_Init(g_pd3dDevice, g_pd3dDeviceContext);

        return true;
    }

    void Cleanup() {
        ImGui_ImplDX11_Shutdown();
        ImGui_ImplWin32_Shutdown();
        ImGui::DestroyContext();

        CleanupDeviceD3D();
        DestroyWindow(overlayWnd);
        UnregisterClassW(L"SEWPRO_Overlay", GetModuleHandle(nullptr));
    }

    void DrawESP(ImDrawList* draw, int gW, int gH) {
        if (!Config::esp_enabled || !Memory::libil2cpp) return;

        
        
        
        uint32_t initBasePtr = Memory::Read<uint32_t>(Memory::libil2cpp + Memory::dynamicInitBase);
        uint32_t staticClass = Memory::Read<uint32_t>(initBasePtr + Offsets::StaticClass);
        
        if (!initBasePtr) return;
        if (!staticClass) return;
        uint32_t currentMatch = Memory::Read<uint32_t>(staticClass + Offsets::CurrentMatch);
        if (!currentMatch) return;

        uint32_t localPlayer = Memory::Read<uint32_t>(currentMatch + Offsets::LocalPlayer);
        if (!localPlayer) return;

        Vector3 localPos = Memory::Read<Vector3>(localPlayer + Offsets::XPose);
        uint32_t followCam = Memory::Read<uint32_t>(localPlayer + Offsets::FollowCamera);
        if (!followCam) return;
        uint32_t cam = Memory::Read<uint32_t>(followCam + Offsets::Camera);
        if (!cam) return;
        
        Matrix4x4 viewProj = Memory::Read<Matrix4x4>(cam + Offsets::MainCameraTransform);
        uint32_t dict = Memory::Read<uint32_t>(currentMatch + Offsets::DictionaryEntities);
        if (!dict) return;
        uint32_t entityArray = Memory::Read<uint32_t>(dict + 0x10); // internal array of List<T>
        if (!entityArray) return;

        ImU32 redColor = ImColor(255, 0, 0, 255);
        ImU32 cyanColor = ImColor(0, 255, 255, 255);

        for (int i = 0; i < 64; i++) {
            uint32_t ent = Memory::Read<uint32_t>(entityArray + 0x10 + (i * 4)); // 32-bit Unity Array header is 0x10, pointers are 4 bytes
            if (!ent || ent == localPlayer) continue;
            if (Memory::Read<bool>(ent + Offsets::Player_IsDead)) continue;

            Vector3 entPos = Memory::Read<Vector3>(ent + Offsets::XPose);
            float dist = (entPos - localPos).Length();
            if (dist > Config::esp_max_distance) continue;

            Vector2 screen = WorldToScreen(entPos, viewProj, gW, gH);
            if (screen.x <= 0 || screen.y <= 0) continue;
            
            if (Config::esp_draw_box) {
                float headZ = entPos.z + 1.8f;
                float feetZ = entPos.z - 0.9f;
                Vector2 head = WorldToScreen({entPos.x, entPos.y, headZ}, viewProj, gW, gH);
                Vector2 feet = WorldToScreen({entPos.x, entPos.y, feetZ}, viewProj, gW, gH);
                
                if (head.y > 0 && feet.y > 0) {
                    float h = std::abs(head.y - feet.y);
                    float w = h / 2.0f;
                    draw->AddRect(ImVec2(head.x - w/2, head.y), ImVec2(head.x + w/2, head.y + h), redColor, 0, 0, 1.5f);
                }
            }

            if (Config::esp_draw_line) {
                draw->AddLine(ImVec2(gW / 2, gH), ImVec2(screen.x, screen.y), cyanColor, 1.0f);
            }

            char buf[32];
            sprintf_s(buf, "Enemy [%dm]", (int)dist);
            draw->AddText(ImVec2(screen.x - 20, screen.y - 30), ImColor(255,255,255), buf);
        }
    }

    void RenderLoop() {
        bool done = false;
        while (!done) {
            MSG msg;
            while (::PeekMessage(&msg, nullptr, 0U, 0U, PM_REMOVE)) {
                ::TranslateMessage(&msg);
                ::DispatchMessage(&msg);
                if (msg.message == WM_QUIT) done = true;
            }
            if (done) break;

            // Phím tắt để thoát hoàn toàn (DELETE)
            if (GetAsyncKeyState(VK_DELETE) & 1) {
                done = true;
                break;
            }

            // Phím tắt bật/tắt Menu (INSERT)
            if (GetAsyncKeyState(VK_INSERT) & 1) {
                Config::showMenu = !Config::showMenu;
                long exStyle = GetWindowLong(overlayWnd, GWL_EXSTYLE);
                if (Config::showMenu) {
                    exStyle &= ~WS_EX_TRANSPARENT; 
                    SetWindowLong(overlayWnd, GWL_EXSTYLE, exStyle);
                    SetWindowPos(overlayWnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_FRAMECHANGED);
                    SetForegroundWindow(overlayWnd); // Force it to take input focus
                } else {
                    exStyle |= WS_EX_TRANSPARENT; 
                    SetWindowLong(overlayWnd, GWL_EXSTYLE, exStyle);
                    SetWindowPos(overlayWnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_FRAMECHANGED);
                }
            }

            int gW = GetSystemMetrics(SM_CXSCREEN);
            int gH = GetSystemMetrics(SM_CYSCREEN);

            // Sync Overlay with Game Window (if attached)
            if (Config::gameAttached) {
                gameWnd = FindWindow(L"BlueStacksApp", NULL);
                if (!gameWnd) gameWnd = FindWindow(NULL, L"BlueStacks App Player");

                if (gameWnd) {
                    RECT gameRect;
                    GetWindowRect(gameWnd, &gameRect);
                    gW = gameRect.right - gameRect.left;
                    gH = gameRect.bottom - gameRect.top;
                    
                    // Only move the window, do not mess with Z-Order constantly
                    SetWindowPos(overlayWnd, NULL, gameRect.left, gameRect.top, gW, gH, SWP_NOZORDER | SWP_NOACTIVATE);
                } else {
                    SetWindowPos(overlayWnd, NULL, 0, 0, gW, gH, SWP_NOZORDER | SWP_NOACTIVATE);
                }
            } else {
                SetWindowPos(overlayWnd, NULL, 0, 0, gW, gH, SWP_NOZORDER | SWP_NOACTIVATE);
            }

            ImGui_ImplDX11_NewFrame();
            ImGui_ImplWin32_NewFrame();
            ImGui::NewFrame();

            // Draw ESP Background
            if (Config::esp_enabled && Config::gameAttached) {
                ImGui::SetNextWindowPos(ImVec2(0, 0));
                ImGui::SetNextWindowSize(ImVec2((float)gW, (float)gH));
                ImGui::Begin("##Background", nullptr, ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoInputs | ImGuiWindowFlags_NoBringToFrontOnFocus);
                DrawESP(ImGui::GetWindowDrawList(), gW, gH);
                ImGui::End();
            }

            // Draw UI
            if (Config::showMenu) {
                ImGui::SetNextWindowSize(ImVec2(400, 300), ImGuiCond_FirstUseEver);
                ImGui::Begin("SEWPRO C++ External [PRO]", &Config::showMenu, ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoCollapse);
                
                
                
                ImGui::TextColored(Config::il2cppFound ? ImVec4(0,1,0,1) : ImVec4(1,1,0,1), "lib:%p", (void*)Memory::libil2cpp);
                
                // Debug Pointers
                if (Memory::libil2cpp) {
                    uint32_t initBasePtr = Memory::Read<uint32_t>(Memory::libil2cpp + Memory::dynamicInitBase);
                    uint32_t staticClass = initBasePtr ? Memory::Read<uint32_t>(initBasePtr + Offsets::StaticClass) : 0;
                    uint32_t currentMatch = staticClass ? Memory::Read<uint32_t>(staticClass + Offsets::CurrentMatch) : 0;
                    uint32_t localPlayer = currentMatch ? Memory::Read<uint32_t>(currentMatch + Offsets::LocalPlayer) : 0;
                    
                    ImGui::Text("InitBase: 0x%X", initBasePtr);
                    ImGui::Text("StaticClass: 0x%X", staticClass);
                    ImGui::Text("CurrentMatch: 0x%X", currentMatch);
                    ImGui::Text("LocalPlayer: 0x%X", localPlayer);
                }
                
                ImGui::Separator();

                if (ImGui::BeginTabBar("MenuTabs")) {
                    if (ImGui::BeginTabItem("Aimbot")) {
                        ImGui::Checkbox("Enable Aimbot", &Config::aimbot_enabled);
                        ImGui::SliderFloat("Smoothness", &Config::aim_smooth, 1.0f, 20.0f);
                        ImGui::EndTabItem();
                    }
                    if (ImGui::BeginTabItem("Visuals")) {
                        ImGui::Checkbox("Enable ESP", &Config::esp_enabled);
                        ImGui::Checkbox("Draw Box", &Config::esp_draw_box);
                        ImGui::Checkbox("Draw Line", &Config::esp_draw_line);
                        ImGui::SliderFloat("Max Distance", &Config::esp_max_distance, 50.0f, 2000.0f);
                        ImGui::EndTabItem();
                    }
                    if (ImGui::BeginTabItem("Hacks")) {
                        ImGui::Checkbox("Speed Hack", &Config::hack_speed);
                        ImGui::Checkbox("No Recoil", &Config::hack_no_recoil);
                        ImGui::Checkbox("No Reload", &Config::hack_no_reload);
                        ImGui::Checkbox("God Mode", &Config::hack_god_mode);
                        ImGui::EndTabItem();
                    }
                    ImGui::EndTabBar();
                }

                ImGui::End();
            }

            ImGui::Render();
            const float clear_color_with_alpha[4] = { 0.0f, 0.0f, 0.0f, 0.0f };
            g_pd3dDeviceContext->OMSetRenderTargets(1, &g_mainRenderTargetView, nullptr);
            g_pd3dDeviceContext->ClearRenderTargetView(g_mainRenderTargetView, clear_color_with_alpha);
            ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
            g_pSwapChain->Present(1, 0); // V-Sync enabled
        }
    }
}























