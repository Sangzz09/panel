#include <windows.h>
#include <iostream>
#include <thread>
#include <string>
#include "Memory.h"
#include "Overlay.h"
#include "Hacks.h"
#include "Config.h"

void BackgroundAttachLoop() { while (true) {
        if (!Config::gameAttached) {
            strcpy_s(Config::connectionStatus, "Waiting for BlueStacks/HD-Player...");
            if (Memory::AttachProcess(L"HD-Player.exe") || Memory::AttachProcess(L"BlueStacksApp.exe")) {
                Config::gameAttached = true;
                strcpy_s(Config::connectionStatus, "Process attached! Scanning for libil2cpp.so...");
            }
        } else if (!Config::il2cppFound) { 
            Memory::libil2cpp = Memory::FindLibraryBase(); 
            if (Memory::libil2cpp != 0) {
                Config::il2cppFound = true;
            }
        } else if (Memory::dynamicInitBase == 0) {
            Memory::dynamicInitBase = Memory::ScanForInitBase();
            if (Memory::dynamicInitBase != 0) {
                char buf[256];
                sprintf_s(buf, "libil2cpp.so found at: 0x%llX (InitBase: 0x%X)", (unsigned long long)Memory::libil2cpp, Memory::dynamicInitBase);
                strcpy_s(Config::connectionStatus, buf);
                
                // Start hack threads once connected and InitBase is found
                std::thread aimbotThread(Hacks::AimbotLoop);
                std::thread memHackThread(Hacks::MemoryHackLoop);
                aimbotThread.detach();
                memHackThread.detach();
            }
        }
        Sleep(1000);
    }
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) { // Start the background attacher thread
    std::thread attacherThread(BackgroundAttachLoop);
    attacherThread.detach();

    if (!Overlay::Initialize()) { 
        MessageBoxA(NULL, "Failed to initialize DirectX 11 Overlay!", "SEWPRO Error", MB_OK | MB_ICONERROR); 
        return 1; 
    }

    // Enter Render Loop (Blocks until closed)
    Overlay::RenderLoop();

    // Cleanup
    Overlay::Cleanup();
    return 0;
}





